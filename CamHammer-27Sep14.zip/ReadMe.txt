Product: Da Vinci Cam Hammer, September 2014

Designer: Zombie Cat, http://zombie-cat.org/

Support:  http://forums.obrary.com/category/designs/da-vinci-cam-hammer

Distributed by:  Obrary, Inc.  http://obrary.com.  Obrary - democratized product design

Description:
The Da Vinci Cam Hammer is a teaching tool that is designed to be cut from plywood on a Laser Cutter.